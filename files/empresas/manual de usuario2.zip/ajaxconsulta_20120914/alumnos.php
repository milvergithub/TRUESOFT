<?php
// El objetivo de este modulo es mostrarte de una forma simple y clara como se puede
// manejar una consulta ajax. Ten en cuenta que este es un metodo simplificado
// cuyo proposito es enseñar, en la practica habra que tomar en cuenta otros mecanismos
// que aseguren la estabilidad y seguridad de un modulo como el siguiente

// esta es una lista con algunas opciones, aunque en la practica estos datos deben salir de 
// alguna tabla en una base de datos
// la estructura que utilizaremos es bastante simple:
//   identificador de la cédula : registros de alumno
// en donde:
//   registro de alumno : id del registro, nombre, edad, grado
$registros = array(
	"1" => 
		array(
			array(100, "Pedro Páramo", 18, 1),
			array(115, "Gilberto Pérez", 19, 2),
			array(200, "Ángel González", 18, 1)
			),
	"2" => 
		array(
			array(100, "Pedro Páramo", 18, 1),
			array(100, "Ángel González", 18, 1),
			array(100, "Roberto Menéndez", 17, 1),
			array(100, "Juan Castro", 20, 3)
			),
	"3" => 
		array(
			array(100, "Ángel González", 18, 1)
			)
	); 

// valida que se haya especificado una tarea
if (!isset( $_POST['tarea'])) 
{
	print false;
	exit;
}

$tarea = $_POST['tarea']; 
switch($tarea)
{
	case '1':	// recuperar los registros del catalogo
			obtenerRegistros();
			break;
			
	default:
			print false;
}

function obtenerRegistros()
{ 
	global $tarea, $registros;
	$cedula = $_POST['cedula'];
	
	if (isset($registros[$cedula]))
	{
		// es mucho mas sencillo manejar el codificador JSON que viene con PHP, tendríamos que
		// colocar algo como lo siguiente
		// print json_encode($registros); 
		
		// pero como soy de la idea que tienes que entender como funcionan las cosas para poder
		// mejorar todo lo que sabes, aqui les va la version con cincel y piedra
		$contador = 0;
		$alumnos = $registros[$cedula];
		print '[';
		foreach ($alumnos as $alumno) 
		{
			if ($contador++ > 0) print ", "; // agregamos esta linea porque cada elemento debe estar separado por una coma
			print "{ \"id\" : $alumno[0], \"nombre\" : \"$alumno[1]\", \"edad\" : $alumno[2], \"grado\" : $alumno[3] }";
		}
		print ']';
	}
	else
		print false;
}
?>