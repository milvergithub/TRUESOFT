<?php
// El objetivo de este demo no es realizar una busqueda con php, sino mostrar lo simple
// que es programar una rutina de autocompletado con jQuery UI, por esta razon no vamos
// a realizar nada importante en este archivo.

// recuperamos el criterio de la busqueda
$criterio = strtolower($_GET["term"]);
if (!$criterio) return;
?>
[<?php

// esta es una lista con algunas opciones, aunque en la practica estos datos deben salir de 
// alguna tabla en una base de datos
// la estructura que utilizaremos es simple:
//   nombre de la cédula : identificador de la cedula
$registros = array(
	"Introducción a la Ingeniería de Sistemas" => 1,
	"Fundamento de Análisis Numérico" => 2,
	"Metodología de la Investigación" => 3
	);

// lo que haremos es algo extremadamente sencillo, recuerda que este no es el objetivo del demo:
// recorre el arreglo y si encuentras el texto, imprime el elemento.
$contador = 0;
foreach ($registros as $descripcion => $id) 
{
	if (strpos(strtolower($descripcion), $criterio) !== false) 
	{
		if ($contador++ > 0) print ", "; // agregamos esta linea porque cada elemento debe estar separado por una coma
		
		// las rutinas de autcompletado de jQuery esperan que cada registro contenga los siguientes datos:
		// registro {
		//   label : "el texto que se desea desplegar en el control",
		//   value : { un objeto o cadena con los datos reales del registro }
		// }
		print "{ \"label\" : \"$descripcion\", \"value\" : { \"id\" : $id, \"descripcion\" : \"$descripcion\" } }";
	}
} // siguiente registro
?>]