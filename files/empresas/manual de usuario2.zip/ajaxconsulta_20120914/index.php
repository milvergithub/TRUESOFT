<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>Consultas Ajax con jQuery</title>
  <link rel="stylesheet" type="text/css" href="css/jquery.ui.css"/>
  <link rel="stylesheet" type="text/css" href="css/default.css"/>
  <style type="text/css">
		#tblAlumnos { margin-bottom: 30px }
		#tblAlumnos .id { min-width: 20px }
		#tblAlumnos .nombre { min-width: 200px }
		#tblAlumnos .numerico { min-width: 60px; text-align: right }
	</style>
</head>
<body>
	<div class="page">
  	<div class="content">
      <h1>Consultas Ajax con jQuery</h1>
      <hr />
      <p class="description">Este es un ejemplo pr&aacute;ctico del mecanismo para consultas Ajax en jQuery.</p>
      <p>Por favor, especifica una c&eacute;dula:</p>
      <table>
      	<tr>
        	<td>Materia:</td>
          <td><input id="txtCedula" type="text" size="50" required /></td>
        </tr>
      </table>
      <table id="tblAlumnos">
        <tr>
          <th class='id'>Registro</th>
          <th class='nombre'>Nombre</th>
          <th class='numerico'>Edad</th>
          <th class='numerico'>Grado</th>
        </tr>
      </table>
      <p class="description">En este demo no hacemos consultas a base de datos, simplemente buscamos registro en un arreglo almacenado en el servidor, el cual tiene los siguientes valores disponibles:</p>
      <ul>
      	<li>Introducción a la Ingeniería de Sistemas</li>
        <li>Fundamento de Análisis Numérico</li>
        <li>Metodología de la Investigación</li>
      </ul>
    </div>
    <div class="footer">Eduardo Ferr&oacute;n { Zeion Software }</div>
  </div>
	<script type="text/javascript" src="lib/jquery.1.7.1.js"></script>
  <script type="text/javascript" src="lib/jquery.ui.1.8.16.js"></script>
  <script type="text/javascript">
	
		// esta rutina se ejecuta cuando jquery esta listo para trabajar
		$(function() 
		{
			// configuramos el control para realizar la busqueda de cedulas
			$("#txtCedula").autocomplete({
				source: "buscar.php", 				/* este es el formulario que realiza la busqueda */
				minLength: 1,									/* con un caracter escrito ejecutamos la consulta para el autocompletado */
				select: registroSeleccionado,	/* esta es la rutina que extrae la informacion del registro seleccionado */
				focus: registroMarcado
			}).focus();
		});
		
		// tras seleccionar un producto, calculamos el importe correspondiente
		function registroMarcado(event, ui)
		{
			var registro = ui.item.value;  	// el servidor nos proporciona los siguientes datos:
																			// cedula : {
																			//   id : numerico,
																			//   descripcion: texto
																			// }
			
			// no quiero que jquery maneje el texto del control porque no puede manejar objetos, 
			// asi que escribimos los datos nosotros y cancelamos el evento
			// (intenta comentando este codigo para ver a que me refiero)
			$("#txtCedula").val(registro.descripcion);
			event.preventDefault();
		}
		
		// tras seleccionar un registro, recuperamos la lista de los alumnos inscritos
		function registroSeleccionado(event, ui)
		{
			var registro = ui.item.value;  	// el servidor nos proporciona los siguientes datos:
																			// cedula : {
																			//   id : numerico,
																			//   descripcion: texto
																			// }
			
			// no quiero que jquery maneje el texto del control porque no puede manejar objetos, 
			// asi que escribimos los datos nosotros y cancelamos el evento
			// (intenta comentando este codigo para ver a que me refiero)
			$("#txtCedula").val(registro.descripcion);
			event.preventDefault();
			
			// ahora recuperamos los registros de los alumnos inscritos bajo esta cedula
			recuperarAlumnos(registro);
		}
		
		// recupera la lista de los alumnos inscritos a la cedula especificada
		function recuperarAlumnos(cedula)
		{
			try
			{
				// preparamos el registro con las instrucciones que enviaremos al servidor
				// en este ejemplo practico, utilizaremos una variable de nombre "task" para indicar
				// al servidor lo que queremos hacer, asi como una variable "cedula" en donde colocaremos
				// el ID de la cedula para la cual deseamos recuperar la lista de alumnos
				var data = "tarea=1&cedula=" + cedula.id;
				$.ajax(
					{
						type				: "post",												// el tipo de consulta, puede ser "get" y "post".
						url					: "alumnos.php",								// el modulo que nos proveera de la informacion que solicitamos
						data				: data,													// los datos relacionados a la consulta Ajax
						context			: { "cedula" : cedula },				// un contexto u objeto con informacion complementaria, este no viaja al servidor
						error				: callback_error,								// que rutina se ejecuta si esto falla
						success			: recuperarAlumnos_callback			// que rutina se ejecuta si esto funciona 
					});
			}
			catch(ex)
			{
				alert(ex.description);
			}
		}
		
		// mostramos un mensaje con la causa del problema
		function callback_error(XMLHttpRequest, textStatus, errorThrown)
		{
			// en ambientes serios esto debe manejarse con mucho cuidado, aqui optamos por una solucion simple
			alert(errorThrown);
		}
		
		// recupera la informacion de los alumnos inscritos a esta cedula
		function recuperarAlumnos_callback(ajaxResponse, textStatus)
		{
			var alumnos = procesarRespuesta(ajaxResponse);
			if (!alumnos)
			{
				//alert("No se encontraron registros para la cédula especificada");
				return;
			}
			
			// recupera la instancia de la tabla en donde colocaremos los registros que recuperamos
			// y elimina todos los registros salvo el primero, que es donde se encuentra el encabezado de la tabla
			var $tabla = $("#tblAlumnos");
			$tabla.find("tr:gt(0)").remove();
			
			// ahora, para cada registro que recuperamos
			var alumno;
			for (var idx in alumnos)
			{
				alumno = alumnos[idx];
				$tabla.append("<tr><td class='id'>" + alumno.id + "</td><td class='nombre'>" + alumno.nombre + "</td><td class='numerico'>" + alumno.edad + "</td><td class='numerico'>" + alumno.grado + "</td></tr>");
			}
		}
		
		// recuperamos la informacion que nos ha enviado el servidor
		function procesarRespuesta(ajaxResponse)
		{ 
			// observa que aqui asumimos que el resultado es un objeto serializado en JSON
			// razon por la cual utilizamos la rutina "eval" para recuperar dicho resultado
			// y convertirlo a un objeto que podamos manejar facilmente
			var response;
			try { eval( 'response=' + ajaxResponse ); } catch(ex) { response = null; }
			
			return response;
		}
		
	</script>
</body>
</html>